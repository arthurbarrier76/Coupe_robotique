#include "joystick.hpp"
#include "Arduino.h"

    Joystick::Joystick(int brocheAxeX, int brocheAxeY){

    }