#ifndef JOYSTICK_HPP
#define JOYSTICK_HPP

    class Joystick{
        private:
            int broche
    }

#endif