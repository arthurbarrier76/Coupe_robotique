<h1> Coupe de Robotique 2022 </h1>

<img src=https://www.coupederobotique.fr/wp-content/uploads/logo-CoupeRobotique_bleu.png height="80%" width="80%" alt="Image Coupe de France de robotique"/>

<h2> Description </h2>
Dans le cadre du BTS nous avons participé à la coupe de France de robotique . Nous avons réaliser la partie proggrammation et système embarqué . Blaise pascal à réaliser la partie modélisation et imprimerie du robot 

<h2> Langages utilisés et cartes utilisées </h2>

  - <b> C++ (POO) </b>
  - <b> ArduinoUNO avec PlateformIO </b>

<h2>  Organisation des parties </h2>

<table>
  <tr>
    <td>Nom</td>
    <td>Prénom</td>
    <td> Partie du robot </td>
    <td> Github </td>
  </tr>
  <tr>
    <td>Berkpinar</td>
    <td>Djem</td>
    <td> Vitrine </td>
    <td> https://github.com/Djembrk </td>
  </tr>
  <tr>
    <td>Bonnard</td>
    <td>Matthias</td>
    <td> Vitrine </td>
  </tr>
  <tr>
    <td>Ashraf Moris</td>
    <td> Marina </td>
    <td> "" </td>
    <td> https://github.com/Marina-ASH </td>
  </tr>
  <tr>
    <td> Barrier</td>
    <td> Arthur </td>
    <td> "Trappe" </td>
    <td> https://github.com/arthurbarrier76 </td>
  </tr>
  <tr>
    <td> Dupuis </td>
    <td> Nael </td>
    <td> "" </td>
    <td> https://github.com/Skoelh </td>
  </tr>
   <tr>
    <td> Leviels </td>
    <td> Benjamin </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Martor-Christophe </td>
    <td> Nils </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Fremaux </td>
    <td> Ronan </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Demares </td>
    <td> Lucille </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Letiec </td>
    <td> Gabriel </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Farhat </td>
    <td> Ayman </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Boulant </td>
    <td> Nicolas </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Spilers </td>
    <td> Florent </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  <tr>
    <td> Bussienne </td>
    <td> Ophelie </td>
    <td> "" </td>
    <td> "" </td>
  </tr>
  
</table>



<h2> Images </h2>

<p align="center">
<b> . </b>
<br />
<br />
<img src="" height="80%" width="80%" alt="Image "/>
<br />
<br />
