#include <Arduino.h>
#include"bras.hpp"

void setup() {
  Bras initialisation();
}

void loop() {
  // put your main code here, to run repeatedly:
  Bras sortirPousser();
  Bras sortirMesurer();
  Bras rentrer();
}