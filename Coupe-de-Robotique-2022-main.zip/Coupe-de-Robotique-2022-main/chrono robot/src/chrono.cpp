#include "chrono.hpp"
#include <MsTimer2.h>


int Chrono::demarrer(){
    

}

int Chrono::getTempsRestant(){
    int chronoMax = 100;
    if (getTempsRestant; chronoMax--){

    }
}

bool Chrono::veriFiniMatch(){
    

}