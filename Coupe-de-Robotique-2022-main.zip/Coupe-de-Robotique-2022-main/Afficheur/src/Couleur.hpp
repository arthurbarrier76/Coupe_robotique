#ifndef COULEUR_HPP
#define COULEUR_HPP

enum class Couleur {
    
    violet, jaune 
};

#endif